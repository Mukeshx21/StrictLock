package com.strictlock.app

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Watches the foreground app. Counts usage of blocked apps; when the limit is hit it sets
 * locked=true (persisted) and from then on covers every blocked app with a message and
 * sends the user Home. Nothing in this app can clear the lock - only uninstalling does.
 */
class BlockerService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { Prefs(this) }

    private var allowed = emptySet<String>()      // essentials, usable even when locked
    private var ignore = emptySet<String>()       // overlays/dialogs that don't change the foreground app
    private var settingsPkgs = emptySet<String>()
    private var overlay: View? = null
    private var counting = false
    private var lastTick = 0L

    private val goHome = Runnable {
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({ hideOverlay() }, 800) // fail-safe: overlay never stays long
    }

    private val tick = object : Runnable {
        override fun run() {
            flush()
            if (prefs.usedMs >= prefs.limitMs) {
                stopCounting()
                prefs.locked = true
                enforce()
            } else {
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) {
                stopCounting()
            } else {
                buildSets()
                rootInActiveWindow?.packageName?.toString()?.let { onForeground(it) }
            }
        }
    }

    override fun onServiceConnected() {
        buildSets()
        val f = IntentFilter(Intent.ACTION_SCREEN_OFF).apply { addAction(Intent.ACTION_USER_PRESENT) }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, f)
        }
        rootInActiveWindow?.packageName?.toString()?.let { onForeground(it) }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onForeground(pkg)
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ->
                if (prefs.armed && prefs.locked && pkg in settingsPkgs) guardSettings()
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        stopCounting()
        hideOverlay()
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
    }

    // ---------- core logic ----------

    private fun onForeground(pkg: String) {
        if (pkg in ignore || !prefs.armed) return
        if (pkg == packageName) { stopCounting(); return }
        if (!isBlocked(pkg)) {
            stopCounting()
            hideOverlay()
            if (prefs.locked && pkg in settingsPkgs) guardSettings()
        } else if (prefs.locked) {
            enforce()
        } else {
            startCounting()
        }
    }

    private fun isBlocked(pkg: String): Boolean {
        if (pkg in allowed) return false
        val chosen = prefs.blocked
        return chosen.isEmpty() || pkg in chosen
    }

    private fun startCounting() {
        if (counting) return
        counting = true
        lastTick = SystemClock.elapsedRealtime()
        handler.postDelayed(tick, 1000)
    }

    private fun stopCounting() {
        if (!counting) return
        flush()
        counting = false
        handler.removeCallbacks(tick)
    }

    /** Durations only (elapsedRealtime), so changing the phone's clock can't cheat. */
    private fun flush() {
        val now = SystemClock.elapsedRealtime()
        prefs.usedMs += now - lastTick
        lastTick = now
    }

    private fun enforce() {
        if (overlay != null) return
        showOverlay()
        handler.removeCallbacks(goHome)
        handler.postDelayed(goHome, 2500)
    }

    /** Best-effort: while locked, bounce the user out of this service's Accessibility settings page. */
    private fun guardSettings() {
        val root = rootInActiveWindow ?: return
        if (root.findAccessibilityNodeInfosByText(getString(R.string.service_label)).isNotEmpty()) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    // ---------- overlay ----------

    private fun showOverlay() {
        if (overlay != null) return
        val view = buildOverlayView()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        )
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(view, lp)
            overlay = view
        } catch (_: Exception) {}
    }

    private fun buildOverlayView(): View {
        fun dp(v: Int) = Ui.dp(this, v)
        fun label(s: String, size: Float, color: Int, face: android.graphics.Typeface) = TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            typeface = face
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.INK)
            setPadding(dp(32), dp(32), dp(32), dp(32))
            addView(ImageView(this@BlockerService).apply {
                setImageResource(R.drawable.ic_logo)
                layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
            })
            addView(label(getString(R.string.locked_caption).uppercase(), 12f, Ui.ACCENT, Ui.MONO).apply {
                letterSpacing = 0.14f
                setPadding(0, dp(40), 0, 0)
            })
            addView(label(getString(R.string.locked_title), 64f, Ui.PAPER, Ui.DISPLAY).apply {
                includeFontPadding = false
                setPadding(0, dp(10), 0, 0)
            })
            addView(label(getString(R.string.locked_body), 17f, Ui.FAINT, Ui.BODY).apply {
                setPadding(0, dp(14), 0, 0)
            })
        }
    }

    private fun hideOverlay() {
        handler.removeCallbacks(goHome)
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        overlay = null
    }

    // ---------- essentials that must always work ----------

    private fun buildSets() {
        val pm = packageManager
        fun handlers(i: Intent) = pm.queryIntentActivities(i, 0).map { it.activityInfo.packageName }

        settingsPkgs = (handlers(Intent(Settings.ACTION_SETTINGS)) + "com.android.settings").toSet()
        val homes = handlers(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
        val dialer = try {
            (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage
        } catch (e: Exception) { null }
        val ime = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')

        ignore = setOfNotNull(
            ime, "com.android.systemui", "android",
            "com.google.android.permissioncontroller", "com.android.permissioncontroller"
        )
        allowed = settingsPkgs + homes + setOfNotNull(dialer) + setOf(
            // calls & emergency
            "com.android.phone", "com.android.server.telecom", "com.android.incallui",
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.incallui",
            "com.android.emergency", "com.android.cellbroadcastreceiver",
            "com.google.android.cellbroadcastreceiver",
            // uninstall dialog
            "com.google.android.packageinstaller", "com.android.packageinstaller",
            "com.samsung.android.packageinstaller", "com.miui.packageinstaller"
        )
    }
}
