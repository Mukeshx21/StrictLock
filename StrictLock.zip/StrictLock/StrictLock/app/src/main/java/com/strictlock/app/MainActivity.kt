package com.strictlock.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private var svcStatus: TextView? = null
    private var bigView: TextView? = null
    private var subView: TextView? = null
    private var barFill: View? = null
    private var chosen = setOf<String>()

    private val ticker = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        if (prefs.armed) buildStatusScreen() else buildSetupScreen()
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    // ---------- screens ----------

    private fun buildSetupScreen() {
        val col = column()
        col.addView(header())
        col.addView(spacer(44))
        col.addView(tv("Set a limit.\nThen it stays locked.", 34f, Ui.INK, Ui.DISPLAY).apply {
            setLineSpacing(0f, 0.95f)
        })
        col.addView(spacer(14))
        col.addView(tv(
            "When the limit is reached, blocked apps stay locked for good. " +
            "Calls (including emergency), Settings and the keyboard keep working.",
            15f, Ui.MUTED
        ).apply { setLineSpacing(0f, 1.25f) })

        // 01 limit
        col.addView(section("01", "Usage limit"))
        val limit = EditText(this).apply {
            hint = "60"
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(4))
            typeface = Ui.DISPLAY
            textSize = 44f
            setTextColor(Ui.INK)
            setHintTextColor(Ui.FAINT)
            background = null
            includeFontPadding = false
            setPadding(0, dp(6), 0, dp(6))
        }
        val unit = caps("minutes").apply { setPadding(dp(8), 0, 0, dp(12)) }
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            addView(limit, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(unit)
        })
        col.addView(rule(Ui.INK, 2))

        // 02 apps
        col.addView(section("02", "Apps"))
        col.addView(rule())
        val appsValue = valueText("All apps  ›")
        col.addView(row("Apps to block", "Blocks everything unless you pick", appsValue) { pickApps(appsValue) })
        col.addView(rule())

        // 03 permissions
        col.addView(section("03", "Permissions"))
        col.addView(rule())
        val s = valueText("")
        svcStatus = s
        col.addView(row("Accessibility service", "Required. Detects the open app", s) {
            open(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        })
        col.addView(rule())
        col.addView(row("Battery settings", "Recommended. Keeps tracking alive", valueText("OPEN  ›")) {
            open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        })
        col.addView(rule())

        col.addView(spacer(28))
        val agree = CheckBox(this).apply {
            text = "I understand: after the limit, blocked apps stay locked permanently."
            textSize = 14f
            typeface = Ui.BODY
            setTextColor(Ui.INK)
            buttonTintList = ColorStateList.valueOf(Ui.INK)
        }
        col.addView(agree)
        col.addView(primary("Start strict mode") { start(limit.text.toString(), agree.isChecked) })

        show(col)
        updateStatus()
    }

    private fun buildStatusScreen() {
        val col = column()
        col.addView(header())
        col.addView(spacer(44))
        col.addView(caps("Status"))

        val big = tv("", 64f, Ui.INK, Ui.DISPLAY).apply {
            includeFontPadding = false
            setPadding(0, dp(10), 0, 0)
        }
        bigView = big
        col.addView(big)

        val sub = tv("", 13f, Ui.MUTED, Ui.MONO).apply { setPadding(0, dp(10), 0, dp(20)) }
        subView = sub
        col.addView(sub)

        val fill = View(this)
        barFill = fill
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 1000f
            setBackgroundColor(Ui.HAIR)
            addView(fill, LinearLayout.LayoutParams(0, MATCH, 0f))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(6))
        })

        col.addView(section("01", "Permissions"))
        col.addView(rule())
        val s = valueText("")
        svcStatus = s
        col.addView(row("Accessibility service", "Must stay on for the lock to work", s) {
            open(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        })
        col.addView(rule())

        show(col)
        updateStatus()
    }

    private fun updateStatus() {
        val on = serviceEnabled()
        svcStatus?.apply {
            text = if (on) "ON" else "OFF  ›"
            setTextColor(if (on) Ui.INK else Ui.ACCENT)
        }
        val big = bigView ?: return
        val sub = subView ?: return
        if (prefs.locked) {
            big.text = "Locked"
            big.setTextColor(Ui.ACCENT)
            sub.text = "Limit reached. Apps are locked."
            setBar(1000, Ui.ACCENT)
        } else {
            val u = prefs.usedMs / 1000
            val limitMin = prefs.limitMs / 60000
            big.text = String.format(Locale.US, "%d:%02d", u / 60, u % 60)
            big.setTextColor(Ui.INK)
            sub.text = "used of $limitMin min"
            val permille = if (prefs.limitMs > 0) minOf(1000L, prefs.usedMs * 1000 / prefs.limitMs).toInt() else 0
            setBar(permille, Ui.INK)
        }
    }

    private fun setBar(permille: Int, color: Int) {
        barFill?.apply {
            setBackgroundColor(color)
            layoutParams = LinearLayout.LayoutParams(0, MATCH, permille.toFloat())
        }
    }

    // ---------- actions ----------

    private fun start(minutesText: String, agreed: Boolean) {
        val minutes = minutesText.toLongOrNull() ?: 0L
        if (minutes <= 0) return toast("Enter a limit in minutes")
        if (!agreed) return toast("Please tick the checkbox")
        if (!serviceEnabled()) {
            toast("Enable the Accessibility service first")
            open(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            return
        }
        AlertDialog.Builder(this, R.style.StrictLockDialog)
            .setTitle("Start strict mode?")
            .setMessage("After $minutes minutes of use, blocked apps lock permanently.")
            .setPositiveButton("Start") { _, _ ->
                prefs.limitMs = minutes * 60_000L
                prefs.usedMs = 0L
                prefs.locked = false
                prefs.blocked = chosen
                prefs.armed = true
                buildStatusScreen()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickApps(value: TextView) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
            .filter { it.activityInfo.packageName != packageName }
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val checked = BooleanArray(apps.size) { apps[it].second in chosen }
        AlertDialog.Builder(this, R.style.StrictLockDialog)
            .setTitle("Apps to block (none = all)")
            .setMultiChoiceItems(apps.map { it.first }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("OK") { _, _ ->
                chosen = apps.filterIndexed { i, _ -> checked[i] }.map { it.second }.toSet()
                value.text = if (chosen.isEmpty()) "All apps  ›" else "${chosen.size} chosen  ›"
            }
            .show()
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun open(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    // ---------- UI building blocks ----------

    private fun dp(v: Int) = Ui.dp(this, v)

    /** Puts the column in a scroll view, handles edge-to-edge insets (Android 15) and bar icon colours. */
    @Suppress("DEPRECATION")
    private fun show(col: LinearLayout) {
        val sv = ScrollView(this).apply {
            setBackgroundColor(Ui.PAPER)
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(col)
            setOnApplyWindowInsetsListener { v, insets ->
                val (top, bottom) = if (Build.VERSION.SDK_INT >= 30) {
                    val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                    i.top to i.bottom
                } else {
                    insets.systemWindowInsetTop to insets.systemWindowInsetBottom
                }
                v.setPadding(0, top, 0, bottom)
                insets
            }
        }
        setContentView(sv)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        sv.requestApplyInsets()
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(20), dp(24), dp(32))
    }

    private fun header() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(ImageView(this@MainActivity).apply {
            setImageResource(R.drawable.ic_logo)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
        })
        addView(tv("StrictLock", 22f, Ui.INK, Ui.DISPLAY).apply { setPadding(dp(12), 0, 0, 0) })
    }

    private fun tv(s: String, size: Float, color: Int = Ui.INK, face: Typeface = Ui.BODY) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        typeface = face
    }

    private fun caps(s: String) =
        tv(s.uppercase(Locale.ROOT), 11f, Ui.MUTED, Ui.MONO).apply { letterSpacing = 0.14f }

    private fun valueText(s: String) = tv(s, 12f, Ui.INK, Ui.MONO).apply {
        letterSpacing = 0.08f
        setPadding(dp(12), 0, 0, 0)
    }

    private fun section(num: String, title: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(32), 0, dp(10))
        addView(tv(num, 11f, Ui.ACCENT, Ui.MONO).apply {
            letterSpacing = 0.14f
            minWidth = dp(28)
        })
        addView(caps(title))
    }

    private fun spacer(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(MATCH, dp(h)) }

    private fun rule(color: Int = Ui.HAIR, h: Int = 1) = View(this).apply {
        setBackgroundColor(color)
        layoutParams = LinearLayout.LayoutParams(MATCH, maxOf(1, dp(h)))
    }

    private fun row(title: String, sub: String?, value: TextView, onClick: () -> Unit): View {
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(title, 16f, Ui.INK, Ui.MEDIUM))
            if (sub != null) addView(tv(sub, 13f, Ui.MUTED).apply { setPadding(0, dp(2), 0, 0) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(14))
            background = Ui.ripple(null)
            isClickable = true
            setOnClickListener { onClick() }
            addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(value)
        }
    }

    private fun primary(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        setAllCaps(false)
        typeface = Ui.MEDIUM
        textSize = 16f
        setTextColor(Ui.PAPER)
        stateListAnimator = null
        minHeight = dp(56)
        minimumHeight = dp(56)
        background = Ui.ripple(Ui.box(Ui.INK, dp(3).toFloat()), "#33FFFFFF")
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(20) }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
