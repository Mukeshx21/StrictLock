package com.strictlock.app

import android.content.Context

/** All state lives here. There is intentionally NO code path that sets locked=false. */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("strictlock", Context.MODE_PRIVATE)

    var armed: Boolean
        get() = sp.getBoolean("armed", false)
        set(v) = sp.edit().putBoolean("armed", v).apply()

    var locked: Boolean
        get() = sp.getBoolean("locked", false)
        set(v) = sp.edit().putBoolean("locked", v).apply()

    var limitMs: Long
        get() = sp.getLong("limitMs", 0L)
        set(v) = sp.edit().putLong("limitMs", v).apply()

    var usedMs: Long
        get() = sp.getLong("usedMs", 0L)
        set(v) = sp.edit().putLong("usedMs", v).apply()

    /** Empty set = block every app except the essentials. */
    var blocked: Set<String>
        get() = sp.getStringSet("blocked", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("blocked", HashSet(v)).apply()
}
