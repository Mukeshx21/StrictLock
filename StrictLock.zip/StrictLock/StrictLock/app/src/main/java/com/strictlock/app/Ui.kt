package com.strictlock.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable

/** Shared look: flat paper + ink, one accent, hairline rules. No shadows, no gradients. */
object Ui {
    val INK = Color.parseColor("#17160F")
    val PAPER = Color.parseColor("#F3F0E8")
    val ACCENT = Color.parseColor("#E8502E")
    val MUTED = Color.parseColor("#6E6A5E")
    val FAINT = Color.parseColor("#B9B4A6")
    val HAIR = Color.parseColor("#D8D3C5")

    val DISPLAY: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val BODY: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val MEDIUM: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val MONO: Typeface = Typeface.create("monospace", Typeface.NORMAL)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun box(fill: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable().apply { setColor(fill); cornerRadius = radiusPx }

    fun ripple(content: Drawable?, color: String = "#26000000"): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.parseColor(color)), content, ColorDrawable(Color.BLACK))
}
