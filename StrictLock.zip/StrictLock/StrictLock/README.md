# StrictLock (Android, Kotlin, no dependencies)

Self-imposed app blocker with no unlock path. Set a usage limit; when it is reached, blocked
apps stay locked. The only way out is uninstalling the app.

## Run
1. Android Studio (Koala or newer) > Open > select this folder > let Gradle sync.
2. Run on an emulator or phone (Android 8.0+).
3. In the app: Enable Accessibility service > enter a limit (use 1 minute to test) > tick the box > Start.
   - Sideloaded APK on Android 13+: if the Accessibility toggle is greyed out, go to
     Settings > Apps > StrictLock > ⋮ > "Allow restricted settings", then try again.
4. Open any other app for a minute. It gets covered and sent Home. Forever, until uninstall.

## Reset while testing
Uninstall and reinstall (backup is disabled so the lock is not restored), or:
`adb uninstall com.strictlock.app`

## Always allowed
Launcher, Settings, dialer/in-call UI, emergency, package installer, keyboard, system UI, this app.

## Files
- BlockerService.kt  - AccessibilityService: tracking, locking, overlay, Settings guard
- MainActivity.kt    - setup + status screen (no unlock UI exists)
- Ui.kt              - colours, fonts, shared look
- res/drawable/ic_logo.xml, ic_launcher_*.xml - logo + adaptive/themed launcher icon
- Prefs.kt           - saved state (armed / locked / limit / used / blocked apps)

## Known limits
- Force stop from App info (or safe mode / adb) can switch the service off. Re-enabling it
  restores the lock. Preventing that would need Device Admin, which would also block uninstall.
- Not compiled by the author: if Gradle/Kotlin shows an error, paste it back for a fix.
